import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-2LRID2IF.js";
import "./chunk-ZSCYCNUI.js";
import "./chunk-GJQPQF2B.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
