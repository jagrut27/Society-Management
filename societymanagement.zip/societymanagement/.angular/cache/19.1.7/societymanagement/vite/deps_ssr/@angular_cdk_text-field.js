import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-UIAO6DBR.js";
import "./chunk-ZWNFCZWJ.js";
import "./chunk-ZSCYCNUI.js";
import "./chunk-GJQPQF2B.js";
import "./chunk-YHCV7DAQ.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
